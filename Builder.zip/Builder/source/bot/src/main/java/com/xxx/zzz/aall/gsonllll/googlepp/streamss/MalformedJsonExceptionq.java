

package com.xxx.zzz.aall.gsonllll.googlepp.streamss;

import java.io.IOException;


public final class MalformedJsonExceptionq extends IOException {
  private static final long serialVersionUID = 1L;

  public MalformedJsonExceptionq(String msg) {
    super(msg);
  }

  public MalformedJsonExceptionq(String msg, Throwable throwable) {
    super(msg, throwable);
  }

  public MalformedJsonExceptionq(Throwable throwable) {
    super(throwable);
  }
}
