
package com.xxx.zzz.aall.gsonllll.googlepp;


public final class JsonSyntaxExceptionq extends JsonParseExceptionq {

  private static final long serialVersionUID = 1L;

  public JsonSyntaxExceptionq(String msg) {
    super(msg);
  }

  public JsonSyntaxExceptionq(String msg, Throwable cause) {
    super(msg, cause);
  }


  public JsonSyntaxExceptionq(Throwable cause) {
    super(cause);
  }
}
