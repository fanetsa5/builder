package com.xxx.zzz.aall.ioppp.socketlll.clientbb;

public class SocketIOExceptionq extends Exception {

    public SocketIOExceptionq() {
        super();
    }

    public SocketIOExceptionq(String message) {
        super(message);
    }

    public SocketIOExceptionq(String message, Throwable cause) {
        super(message, cause);
    }

    public SocketIOExceptionq(Throwable cause) {
        super(cause);
    }
}
