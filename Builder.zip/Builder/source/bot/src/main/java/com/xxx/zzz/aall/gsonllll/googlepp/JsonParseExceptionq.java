

package com.xxx.zzz.aall.gsonllll.googlepp;


public class JsonParseExceptionq extends RuntimeException {
  static final long serialVersionUID = -4086729973971783390L;


  public JsonParseExceptionq(String msg) {
    super(msg);
  }


  public JsonParseExceptionq(String msg, Throwable cause) {
    super(msg, cause);
  }


  public JsonParseExceptionq(Throwable cause) {
    super(cause);
  }
}
