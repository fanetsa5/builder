

package com.xxx.zzz.aall.gsonllll.googlepp;

import java.lang.reflect.Type;


public interface JsonSerializerq<T> {


  public JsonElementq serialize(T src, Type typeOfSrc, JsonSerializationContextq context);
}
