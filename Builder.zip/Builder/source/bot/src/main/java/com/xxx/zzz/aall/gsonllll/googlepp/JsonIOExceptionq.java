
package com.xxx.zzz.aall.gsonllll.googlepp;


public final class JsonIOExceptionq extends JsonParseExceptionq {
  private static final long serialVersionUID = 1L;

  public JsonIOExceptionq(String msg) {
    super(msg);
  }

  public JsonIOExceptionq(String msg, Throwable cause) {
    super(msg, cause);
  }


  public JsonIOExceptionq(Throwable cause) {
    super(cause);
  }
}
