

package com.xxx.zzz.aall.gsonllll.googlepp;

import java.lang.reflect.Type;


public interface JsonSerializationContextq {


  public JsonElementq serialize(Object src);


  public JsonElementq serialize(Object src, Type typeOfSrc);
}
