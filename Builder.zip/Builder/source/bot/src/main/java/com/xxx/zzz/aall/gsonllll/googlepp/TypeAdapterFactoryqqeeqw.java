

package com.xxx.zzz.aall.gsonllll.googlepp;

import com.xxx.zzz.aall.gsonllll.googlepp.reflectsbb.TypeTokenq;


public interface TypeAdapterFactoryqqeeqw {


  <T> TypeAdapterqdscvvf<T> create(Gsonq gson, TypeTokenq<T> type);
}
