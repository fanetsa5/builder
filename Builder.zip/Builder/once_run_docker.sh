#!/bin/bash

sudo docker run -p 8082:80 --rm -it builder2
