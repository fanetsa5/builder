#!/usr/bin/env python3

from .new_alignment import NewAlignment
