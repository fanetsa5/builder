#!/usr/bin/env python3

from .method_rename import MethodRename
